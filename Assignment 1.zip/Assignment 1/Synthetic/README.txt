This folder contains a 2-dimensional synthetic data for binary classification. In the data files provided, each row is a separate training example; the first 2 columns are the features, while the last column is has the labels (+1/-1). 

Files:
train.txt - Training instances + labels (250 x 3)
test.txt - Test instances + labels (750 x 3)

Folder:
CrossValidation - contains the train and test data for each fold of the 5-fold cross-validation procedure on the training set.
