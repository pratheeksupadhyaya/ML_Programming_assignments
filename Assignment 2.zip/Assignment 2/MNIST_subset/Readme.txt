There are four text files/matrices here,

'train_samples.txt'             4000x784
'train_labels.txt'              4000x1
'test_samples.txt'              1000x784
'test_labels.txt'               1000x1

Each row in 'train_samples.txt' or 'test_samples.txt' is a sample of a handwritten
digit.  'train_labels.txt' and 'test_labels.txt' gives
corresponding groundtruth labels, '0' to '9'.  Note the number of training
samples for each class is around 400, but not exactly 400.





